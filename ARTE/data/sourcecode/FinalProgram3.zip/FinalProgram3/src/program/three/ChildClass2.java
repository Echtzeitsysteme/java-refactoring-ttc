package program.three;

public class ChildClass2 extends SecurityManager {
	
	public void method(){
		System.out.println("Hello World");
	}
}

