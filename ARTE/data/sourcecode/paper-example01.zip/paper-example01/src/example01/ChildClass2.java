package example01;

public class ChildClass2 extends ParentClass {
	
	public ChildClass2(){
		
	}
	
	public void method(String string, int k) {
		int i = 0;
		while(i++<k)System.out.println(string);
	}

}
