package example01;

public class ChildClass1 extends ParentClass {
	
	public ChildClass1(){}
	
	public void method(String message, int repeat) {
		for(int i=0; i<repeat; i++){
			System.out.println(message);
		}
	}
	
	public static void main(String[] args){
		ChildClass1 c1 = new ChildClass1();
		c1.method("c1:Hello World", 3);
		
		ChildClass2 c2 = new ChildClass2();
		c2.method("c2:Hello World", 3);
	}
}
