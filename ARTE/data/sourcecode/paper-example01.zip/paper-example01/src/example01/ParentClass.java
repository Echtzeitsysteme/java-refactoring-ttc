package example01;

public class ParentClass {
	
	public ParentClass(){
		
	}

}
