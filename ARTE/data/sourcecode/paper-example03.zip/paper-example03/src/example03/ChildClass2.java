package example03;

public class ChildClass2 extends ParentClass {
	
	public void method() {
		System.out.println("Hello World!");
	}

}
