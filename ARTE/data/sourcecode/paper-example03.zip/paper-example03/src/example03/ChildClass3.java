package example03;

public class ChildClass3 extends ParentClass {

}
