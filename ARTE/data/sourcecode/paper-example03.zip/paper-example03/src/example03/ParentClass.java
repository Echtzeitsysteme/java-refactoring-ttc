package example03;

public class ParentClass {

}
