package example03;

public class ChildClass1 extends ParentClass {
	
	public void method() {
		System.out.println("Hello World!");
	}
	
	public static void main(String[] args) {
		ChildClass1 c = new ChildClass1();
		c.method();
	}
	
}
