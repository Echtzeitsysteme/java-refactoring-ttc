package hidden.program.two;

public class ChildClass3 extends ParentClass {

	public void method(){
		System.out.println("k="+k);
	}

	public String third() {
		return "Hello World";
	}
	
}
