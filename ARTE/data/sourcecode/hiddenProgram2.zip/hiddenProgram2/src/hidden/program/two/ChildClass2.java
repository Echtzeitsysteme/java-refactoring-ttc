package hidden.program.two;

public class ChildClass2 {
	
	public void second(){
		System.out.println("Hello World");
	}

}
