package hidden.program.two;

public class ParentClass {
	public int k = 3;
}
