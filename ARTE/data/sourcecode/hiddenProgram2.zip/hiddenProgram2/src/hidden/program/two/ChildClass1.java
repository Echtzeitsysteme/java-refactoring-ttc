package hidden.program.two;

public class ChildClass1 extends ParentClass {
	
	public void method(){
		System.out.println("k="+k);
	}
	
	public void second(){
		ChildClass3 c = new ChildClass3();
		String s = c.third();
		System.out.println(s);
	}

	public static void main(String[] args) {
		ChildClass1 c1 = new ChildClass1();
					c1.method();
		ChildClass3 c3 = new ChildClass3();
					c3.method();
	}
}
