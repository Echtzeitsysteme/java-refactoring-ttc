package example04;

public class ChildClass2 {

	public void method(){
		System.out.println("Hello World!");
	}

}
