package example04;

public class ChildClass1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public void method(){
		System.out.println("Hello World!");
	}

}
