package hidden.program.three;

public class ChildClass2 {
	
	public void method(){
		System.out.println("Hello World");
	}

}
