package program.two;

public class F extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
