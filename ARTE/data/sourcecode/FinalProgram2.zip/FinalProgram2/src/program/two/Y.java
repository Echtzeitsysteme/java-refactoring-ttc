package program.two;

public class Y extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
