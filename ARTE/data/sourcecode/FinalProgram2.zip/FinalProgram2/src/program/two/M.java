package program.two;

public class M extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
