package program.two;

public class X extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
