package program.two;

public class Q extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
