package program.two;

public class Z extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
