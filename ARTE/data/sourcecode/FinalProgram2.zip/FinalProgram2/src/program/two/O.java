package program.two;

public class O extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
