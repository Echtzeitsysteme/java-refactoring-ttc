package program.two;

public class W extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
