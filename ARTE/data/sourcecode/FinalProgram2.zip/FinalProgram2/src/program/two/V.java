package program.two;

public class V extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
