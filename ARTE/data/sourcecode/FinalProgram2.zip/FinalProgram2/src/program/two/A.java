package program.two;

public class A {

}
