package program.two;

public class L extends A {

	public void method(){
		System.out.println("Hello World!");
	}

}
