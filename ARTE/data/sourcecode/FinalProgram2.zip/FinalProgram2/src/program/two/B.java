package program.two;

public class B extends A {
	
	public static void main(String[] args) {
		B b = new B();
		System.out.print("B: ");
		b.method();
		
		C c = new C();
		System.out.print("C: ");
		c.method();
		
		D d = new D();
		System.out.print("D: ");
		d.method();
		
		E e = new E();
		System.out.print("E: ");
		e.method();
		
		F f = new F();
		System.out.print("F: ");
		f.method();
		
		G g = new G();
		System.out.print("G: ");
		g.method();
		
		H h = new H();
		System.out.print("H: ");
		h.method();
		
		I i = new I();
		System.out.print("I: ");
		i.method();
		
		J j = new J();
		System.out.print("J: ");
		j.method();
		
		K k = new K();
		System.out.print("K: ");
		k.method();
		
		L l = new L();
		System.out.print("L: ");
		l.method();
		
		M m = new M();
		System.out.print("M: ");
		m.method();
		
		N n = new N();
		System.out.print("N: ");
		n.method();
		
		O o = new O();
		System.out.print("O: ");
		o.method();
		
		P p = new P();
		System.out.print("P: ");
		p.method();
		
		Q q = new Q();
		System.out.print("Q: ");
		q.method();
		
		R r = new R();
		System.out.print("R: ");
		r.method();
		
		S s = new S();
		System.out.print("S: ");
		s.method();
		
		T t = new T();
		System.out.print("T: ");
		t.method();
		
		U u = new U();
		System.out.print("U: ");
		u.method();
		
		V v = new V();
		System.out.print("V: ");
		v.method();
		
		W w = new W();
		System.out.print("W: ");
		w.method();
		
		X x = new X();
		System.out.print("X: ");
		x.method();
		
		Y y = new Y();
		System.out.print("Y: ");
		y.method();
		
		Z z = new Z();
		System.out.print("Z: ");
		z.method();
	}

	public void method(){
		System.out.println("Hello World!");
	}

}
