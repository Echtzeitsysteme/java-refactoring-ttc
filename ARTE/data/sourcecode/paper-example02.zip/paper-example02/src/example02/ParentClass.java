package example02;

public class ParentClass {
	
	public ParentClass() {}
	
	public void method() {
		System.out.println("Parent says Hello World!");
	}

}
