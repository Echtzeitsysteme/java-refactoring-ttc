package example02;

public class ChildClass2 extends ParentClass {
	
	public ChildClass2() {}
	
	public void method() {
		System.out.println("Child says Hello World!");
	}

}
