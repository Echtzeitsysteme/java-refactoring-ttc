package hidden.program.one;

public class ParentClass {

}
