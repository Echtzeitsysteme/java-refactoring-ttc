package program.one;

public class FinalClass00 {

}
